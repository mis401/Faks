
public class Automobil{

    [Key]
    public int ID {get;set;}

    public Model Model {get;set;}
    public Marka Marka {get;set;}

    public Boja Boja {get;set;}
    
    public double Cena {get;set;}

    public Prodavnica Prodavnica {get;set;}

}